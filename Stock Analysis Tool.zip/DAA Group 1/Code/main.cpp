#include "raylib.h"
#include <vector>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>

using namespace std;

// Class to store the result of stock analysis
class StockResult
{
private:
    int maxProfit;
    int buyDay;
    int sellDay;
    string buyDate;
    string sellDate;

public:
    // Constructor to initialize the stock analysis result
    StockResult(int maxProfit, int buyDay, int sellDay, const string &buyDate, const string &sellDate)
        : maxProfit(maxProfit), buyDay(buyDay), sellDay(sellDay), buyDate(buyDate), sellDate(sellDate) {}

    // Getters for private member variables
    int getMaxProfit() const { return maxProfit; }
    int getBuyDay() const { return buyDay; }
    int getSellDay() const { return sellDay; }
    string getBuyDate() const { return buyDate; }
    string getSellDate() const { return sellDate; }
};

// Function to find the maximum profit from stock prices
StockResult findMaxProfit(const vector<int> &prices, const vector<string> &dates)
{
    int n = prices.size();
    if (n < 2)
        return StockResult(0, -1, -1, "", ""); // Not enough data to buy and sell

    int maxProfit = 0;
    int minPrice = prices[0];
    int buyDay = 0, sellDay = 0, tempBuyDay = 0;

    // Iterate through prices to determine the best days to buy and sell
    for (int i = 1; i < n; ++i)
    {
        if (prices[i] < minPrice)
        {
            minPrice = prices[i];
            tempBuyDay = i;
        }
        int profit = prices[i] - minPrice;
        if (profit > maxProfit)
        {
            maxProfit = profit;
            buyDay = tempBuyDay;
            sellDay = i;
        }
    }

    // Return the results including the buy and sell dates
    string buyDate = dates[buyDay];
    string sellDate = dates[sellDay];

    return StockResult(maxProfit, buyDay, sellDay, buyDate, sellDate);
}

// Load stock data from file
bool loadStockData(const string &filename, vector<string> &dates, vector<int> &prices)
{
    ifstream file(filename);
    if (!file.is_open())
    {
        cerr << "Error: Could not open file " << filename << endl;
        return false;
    }

    string date;
    int price;
    while (file >> date >> price)
    {
        dates.push_back(date);
        prices.push_back(price);
    }
    file.close();
    return true;
}

int main()
{
    const int screenWidth = 1280;
    const int screenHeight = 720;
    InitWindow(screenWidth, screenHeight, "Stock Price Analysis Tool");

    vector<string> companyFiles = {"MeezanBank.txt", "HBL.txt", "BankAlHabib.txt", "UBL.txt"};
    vector<string> companyNames = {"Meezan Bank", "HBL", "Bank Al Habib Ltd", "UBL"};
    int selectedCompany = 0;
    bool companySelected = false;

    vector<string> dates;
    vector<int> stockPrices;

    SetTargetFPS(60);

    while (!WindowShouldClose())
    {
        BeginDrawing();
        ClearBackground(DARKGRAY);

        if (!companySelected)
        {
            // Display company selection menu
            DrawText("Select a Company:", 20, 20, 20, WHITE);
            for (int i = 0; i < companyNames.size(); ++i)
            {
                Color color = (i == selectedCompany) ? YELLOW : WHITE;
                DrawText(companyNames[i].c_str(), 40, 60 + i * 30, 20, color);
            }

            if (IsKeyPressed(KEY_DOWN))
                selectedCompany = (selectedCompany + 1) % companyNames.size();
            if (IsKeyPressed(KEY_UP))
                selectedCompany = (selectedCompany - 1 + companyNames.size()) % companyNames.size();
            if (IsKeyPressed(KEY_ENTER))
            {
                if (loadStockData(companyFiles[selectedCompany], dates, stockPrices))
                {
                    companySelected = true;
                }
            }
        }
        else
        {
            // Perform stock price analysis
            StockResult result = findMaxProfit(stockPrices, dates);

            float xSpacing = (screenWidth - 150) / (float)stockPrices.size();
            float yScaling = (float)(screenHeight - 250) / (*max_element(stockPrices.begin(), stockPrices.end()) + 100);

            // Draw grid for reference
            for (int i = 0; i < screenWidth; i += 100)
            {
                DrawLine(i, 0, i, screenHeight, GRAY);
            }
            for (int i = 0; i < screenHeight; i += 50)
            {
                DrawLine(0, i, screenWidth, i, GRAY);
            }

            if (result.getBuyDay() != -1 && result.getSellDay() != -1)
            {
                // Highlight the best buy-sell period
                Vector2 buyPos = {result.getBuyDay() * xSpacing + 50, screenHeight - stockPrices[result.getBuyDay()] * yScaling - 100};
                Vector2 sellPos = {result.getSellDay() * xSpacing + 50, screenHeight - stockPrices[result.getSellDay()] * yScaling - 100};

                for (int i = result.getBuyDay(); i < result.getSellDay(); i++)
                {
                    Vector2 start = {i * xSpacing + 50, screenHeight - stockPrices[i] * yScaling - 100};
                    Vector2 end = {(i + 1) * xSpacing + 50, screenHeight - stockPrices[i + 1] * yScaling - 100};
                    DrawLineEx(start, end, 6.0f, GREEN);
                }
            }

            // Draw stock prices as a line chart
            for (int i = 0; i < stockPrices.size() - 1; i++)
            {
                Vector2 start = {i * xSpacing + 50, screenHeight - stockPrices[i] * yScaling - 100};
                Vector2 end = {(i + 1) * xSpacing + 50, screenHeight - stockPrices[i + 1] * yScaling - 100};
                DrawLineEx(start, end, 2.0f, SKYBLUE);
            }

            if (result.getBuyDay() != -1 && result.getSellDay() != -1)
            {
                // Mark buy and sell points
                Vector2 buyPos = {result.getBuyDay() * xSpacing + 50, screenHeight - stockPrices[result.getBuyDay()] * yScaling - 100};
                Vector2 sellPos = {result.getSellDay() * xSpacing + 50, screenHeight - stockPrices[result.getSellDay()] * yScaling - 100};

                DrawCircleV(buyPos, 5, GREEN);
                DrawCircleV(sellPos, 5, RED);

                // Display analysis results
                DrawRectangle(0, 0, screenWidth, 120, DARKBLUE);
                DrawText("Stock Analysis Dashboard", 20, 10, 30, WHITE);
                DrawText(TextFormat("Buy on %s (Price: %d)", result.getBuyDate().c_str(), stockPrices[result.getBuyDay()]), 20, 50, 25, GREEN);
                DrawText(TextFormat("Sell on %s (Price: %d)", result.getSellDate().c_str(), stockPrices[result.getSellDay()]), 20, 80, 25, RED);
                DrawText(TextFormat("Max Profit: $%d", result.getMaxProfit()), 600, 50, 25, GREEN);
            }
            else
            {
                DrawText("No profitable buy-sell pairs found.", 50, 20, 20, DARKGRAY);
            }

            // Axis labels and lines
            DrawLine(30, screenHeight - 100, 30, 200, WHITE); // y-axis for "Price"
            DrawTriangle((Vector2){25, 210}, (Vector2){35, 210}, (Vector2){30, 190}, WHITE);
            DrawText("Price", 10, 160, 25, WHITE);

            DrawLine(30, screenHeight - 100, screenWidth - 100, screenHeight - 100, WHITE); // x-axis for "Days"
            DrawTriangle((Vector2){screenWidth - 110, screenHeight - 110}, (Vector2){screenWidth - 110, screenHeight - 90}, (Vector2){screenWidth - 90, screenHeight - 100}, WHITE);
            DrawText("Days", screenWidth - 200, screenHeight - 70, 25, WHITE);

            // Display selected company name
            DrawText(companyNames[selectedCompany].c_str(), 20, screenHeight - 40, 25, LIGHTGRAY);

            // Option to go back and select another bank
            DrawText("Press BACKSPACE to go back and select another bank.", 20, screenHeight - 80, 20, LIGHTGRAY);
            if (IsKeyPressed(KEY_BACKSPACE))
            {
                companySelected = false;
                dates.clear();
                stockPrices.clear();
            }
        }

        EndDrawing();
    }

    CloseWindow(); // Close the window and OpenGL context
    return 0;
}